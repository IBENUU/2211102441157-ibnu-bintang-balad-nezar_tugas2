import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
/**
 * Write a description of class enemies here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class enemies extends Actor
{
    public enemies()
    {
        Random rnd = new Random();
        this.setImage(new GreenfootImage("bee.png"));
        GreenfootImage myImage = getImage();
        int myNewHeight = (int)myImage.getHeight()/5;
        int myNewWidth = (int)myImage.getWidth()/5;
        myImage.scale(myNewWidth, myNewHeight);
    }
    public void act()
    {
        this.setLocation(this.getX()-3, this.getY());
        if(this.getX()<=0){
            World wrld = this.getWorld();
            wrld.addObject(new enemies(), wrld.getWidth()-1, new Random().nextInt(wrld.getHeight()-1));
            wrld.removeObject(this);
        }    
    }
}
